CREATE TABLE `2014302580073_professor_info` (
  `name` varchar(45) NOT NULL,
  `educationBackground` varchar(1000) DEFAULT NULL,
  `researchInterests` varchar(1000) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `phone` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
