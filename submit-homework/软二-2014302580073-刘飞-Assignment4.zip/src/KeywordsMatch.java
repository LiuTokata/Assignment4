import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class KeywordsMatch 
{
	//private List<String> keywords;
	private String keywords;
	static final private ArrayList<Search> search=new ArrayList<Search>();
	//String[] stopWords;
	private DataRead data=new DataRead();
	private ArrayList<ProfessorInfo> list=data.read();
	
	
	public void calTF(String text)
	{
		for(ProfessorInfo pro:list)
		{
			Search result=new Search();
			result.setPi(pro);
			search.add(result);
		}
		this.keywords=text;
		
	    //for(int j=0;j<searchResult.size();j++)
		for(Search result:search)
		{
		

			double amount = 0;//�ܴ��� 
			double ka = 0;//�ؼ��ʴ���
			double tf;
			String [] message;
			ProfessorInfo pi=result.getPi();
			//name
			message = pi.getName().split(" ");
			for(String m:message)
			{
				
					if(m.contains(keywords))
					{
						ka++;
					}
				
				amount++;
			}
			//email
			message = pi.getEmail().split(" ");
			for(String m:message)
			{
				
					if(m.contains(keywords))
					{
						ka++;
					}
				
				amount++;
			}
			//phone
			message = pi.getPhone().split(" ");
			for(String m:message)
			{
				
					if(m.contains(keywords))
					{
						ka++;
					}
				
				amount++;
			}
			//EducationBackground
			message = pi.getEducationBackground().split(" ");
			for(String m:message)
			{
				
					if(m.contains(keywords))
					{
						ka++;
					}
				
				amount++;
			}
			//ResearchInterests
			message = pi.getResearchInterests().split(" ");
			for(String m:message)
			{
				
					if(m.contains(keywords))
					{
						ka++;
					}
				
				amount++;
			}
			//get tf
			tf=ka/amount;
			
			result.setTf(tf);
	
		}
	}
	public ArrayList<Search> sort(ArrayList<Search> search)
	{
		ArrayList<Search> sr=new ArrayList<Search>();
		Comparator com = new Comparator();
		
		for (int i = 0; i<search.size(); i++)
		 {
			 int max=0;
			
			 double tf=search.get(i).getTf();
			 
			 if(tf !=0.0)
			 {
				 
				 for(int j=i+1;j<search.size();j++)
					{
						if(com.compare(search.get(i), search.get(j))==1)
						{
							max=i;
						}
						else
						{
							max=j;
						}
					}
				 sr.add(search.get(max));
				 
			 }
			 
			
		 }
		 
		return sr;
	}
	public ArrayList<Search> getSearchResult()
	{
		return search;
	}
	class Comparator
	{
		public int compare(Search sr1,Search sr2)
		{
			if(sr1.getTf()>sr2.getTf())
				return 1;
			else
				return 0;
		}
		
	}

}
