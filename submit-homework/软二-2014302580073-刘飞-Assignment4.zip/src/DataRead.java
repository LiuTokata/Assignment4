import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class DataRead 
{
	private String url = "jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456";
	private Connection getConnection(String url) 
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(url);
			return conn;
		}
        catch (Exception e) 
		{
			e.printStackTrace();
			return null;
		}
	}
	public ArrayList<ProfessorInfo> read() 
	{
		ArrayList<ProfessorInfo> list=new ArrayList<ProfessorInfo>();
		try 
		{
			Connection con=getConnection(url);
			PreparedStatement ps;
			ps = con.prepareStatement("select * from 2014302580073_professor_info");
			ResultSet rs  =  ps.executeQuery();//ִ�в�ѯ
			while(rs.next())
			{
			  ProfessorInfo data=null;
			  //Map<String,String> emtel=new HashMap<String,String>(); 
			  //emtel.put(rs.getString(4),rs.getString(5));
			  data = new ProfessorInfo(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5));
			  list.add(data);
			  //System.out.println(rs.getString(4));
			}
			
			con.close();
			return list;
		} 
		catch (SQLException e) 
		{
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
			return null;
		}//����������
		
		
	}
}
