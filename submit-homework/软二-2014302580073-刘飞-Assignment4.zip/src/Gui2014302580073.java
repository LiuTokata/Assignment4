import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.Scrollbar;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;

public class Gui2014302580073 extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	static JTextArea textArea = new JTextArea();
	private JScrollPane scrollPane;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui2014302580073 frame = new Gui2014302580073();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Gui2014302580073() {
		setTitle("\u641C\u7D22\u5668");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 413, 300);
		contentPane = new JPanel();
		contentPane.setBackground(Color.GREEN);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		textField = new JTextField();
		textField.setBounds(0, 0, 222, 33);
		contentPane.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("Search");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) 
			{
				KeywordsMatch kw=new KeywordsMatch();
				String text=textField.getText().trim();
				kw.calTF(text);
				ArrayList<Search> result1=kw.sort(kw.getSearchResult());
				//ArrayList<SearchResult> result=kw.calTF(text);
				for(int i=0;i<result1.size();i++)
				{
					ProfessorInfo pi=result1.get(i).getPi();
				    textArea.setText(pi.getName()+pi.getEducationBackground()+pi.getResearchInterests()+pi.getEmail()+pi.getPhone());
				}
			}
		});
		btnNewButton.setBounds(230, 0, 106, 33);
		contentPane.add(btnNewButton);
		
		
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setBackground(Color.YELLOW);
		textArea.setEditable(false);
		textArea.setBounds(0, 43, 363, 218);
		contentPane.add(textArea);
		
		scrollPane = new JScrollPane(textArea,JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(0, 43, 397, 218);
		contentPane.add(scrollPane);
		
	}
}
