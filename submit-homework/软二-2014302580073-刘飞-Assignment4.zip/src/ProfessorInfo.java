import java.util.Map;

public class ProfessorInfo {
	private String name;
	//private Map<String, String> contactInfo;
	private String educationBackground;
	private String researchInterests;
	private String email;
	private String phone;

	
	public ProfessorInfo(String name,String educationBackground, String researchInterests,String email,String phone) 
	{
		super();
		this.name=name;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
		this.email=email;
		this.phone=phone;
	}

	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	/*public Map<String, String> getContactInfo() {
		return contactInfo;
	}

	public void setContactInfo(Map<String, String> contactInfo) {
		this.contactInfo = contactInfo;
	}*/

	public String getEducationBackground() {
		return educationBackground;
	}

	public void setEducationBackground(String educationBackground) {
		this.educationBackground = educationBackground;
	}

	public String getResearchInterests() {
		return researchInterests;
	}

	public void setResearchInterests(String researchInterests) {
		this.researchInterests = researchInterests;
	}

}
