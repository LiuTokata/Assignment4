
public class Search 
{
	private ProfessorInfo pi;
	private double tf;
	/*SearchResult(ProfessorInfo pi)
	{
		this.pi=pi;
	}
	SearchResult(ProfessorInfo pi,double tf)
	{
		this.pi=pi;
		this.tf=tf;
	}*/
	public ProfessorInfo getPi()
	{
		return pi;
	}
	public void setPi(ProfessorInfo pi)
	{
		this.pi=pi;
	}
	public double getTf()
	{
		return tf;
	}
	public void setTf(double tf)
	{
		this.tf=tf;
	}
}
